<?php>
$servername="localhost";
$username="root";
password="";
$dbname="emploee_db";
$conn=new mysqli($servername,$username,$password);
if($conn->connect_error)
{
die("connection failed",$conn->connect_error);
}
echo"connected successfully";
$sql="desc tbl_healthinformation";
if($conn->query($sql)==TRUE)
{
	echo"<br>";
	echo"connected to the table";
}
else
{
echo "error";
}
echo"<br>";
$empId=$_POST['empId'];
$empName=$_POST['empName'];
$mobileNo=$_POST['mobileNo'];
$bloodGroup=$_POST['bloodGroup'];
$height=$_POST['height'];
$weight=$_POST['weight'];
$eyeColour=$_POST['eyeColour'];
$sql1="select * from tbl_healthinformation where bloodGroup=O+"
$result=$conn->query($sql1);
if($result->num_rows>0)
{
	echo"<b>empId empName mobileNo bloodGroup height weight eyeColour<br>"
while($row=$result->fetch_assoc())
{
	echo $row["empId"]." ".$row["empName"]." ".$row["mobileNo]." ".$row["bloodGroup"]." ".["height"]." ".["weight"]." ".["eyeColour"]."<br>";
}
}
else
{
	echo"empty table";
}
$conn->close();
?>

